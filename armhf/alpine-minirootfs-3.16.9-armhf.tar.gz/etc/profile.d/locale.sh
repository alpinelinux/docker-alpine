export CHARSET=UTF-8
export LANG=C.UTF-8
export LC_COLLATE=C
